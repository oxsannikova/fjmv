# Fire Jumper Mission Validator Library Package

This is a package with helper functions to validate solution for Fire Jumper Security Mission.